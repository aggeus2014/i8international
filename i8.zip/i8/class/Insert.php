
<?php



class Insert(){
	



	
}