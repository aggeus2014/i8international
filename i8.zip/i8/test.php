<?php

	include('connect.php');




				$queindirectref = $db->query("SELECT COUNT(refId) FROM Referrals WHERE mainSponsor = '".$sponsor."' and type = 'indirect'");
				$indirectcount = $queindirectref->fetch_array();
				$idcnt = $indirectcount[0] + 1;


			
				$parent = '11';	

				for($i = 1;$i <= 12 ;$i++){						

						$topin = $db->query("SELECT parentId,userId FROM Users WHERE userId = '".$parent."' AND parentId IS NOT NULL");
						$intop = $topin->fetch_array();
						echo "parent:". $in = $intop[0];
						
						 echo "user:".$intop[1]."<br/>";

						 if($intop2[0] != 0){

							 $insertindirectRef = $db->query("INSERT INTO `Referrals`(`refId`, `mainSponsor`, `subSponsor`, `amount`, `count`, `status`,`type`, `referralDate`, `encashedDate`) 
							 		 						 VALUES ('','".$intop[1]."','','10','','pending','indirect',now(),'')");

						 }
						 
						 $parent = $in;

					}


			
