<?php

	$db = mysqli_connect("localhost","root","","i8") or die("Error".mysqli_error($link));

?>